package src;

public class MVCPatternExample {
    public static void main(String[] args) {
        Student model = new Student();
        model.setName("Ilango");
        model.setId("78654");
        model.setGrade("A");

        StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);

        controller.updateView();

        System.err.println();
        controller.setStudentName("Thamizh");
        controller.setStudentId("89765");
        controller.setStudentGrade("B");
        controller.updateView();
    }
}