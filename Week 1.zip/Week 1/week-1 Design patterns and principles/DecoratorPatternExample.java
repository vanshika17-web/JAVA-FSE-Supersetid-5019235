import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

interface Notifier {
    void send(String message);
}

class EmailNotifier implements Notifier {
    @Override
    public void send(String message) {
        String formattedMessage = formatMessage(message);
        System.out.println("Sending Email: " + formattedMessage);
    }

    private String formatMessage(String message) {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + " - " + message;
    }
}

abstract class NotifierDecorator implements Notifier {
    protected Notifier wrappedNotifier;

    public NotifierDecorator(Notifier notifier) {
        this.wrappedNotifier = notifier;
    }

    @Override
    public void send(String message) {
        wrappedNotifier.send(message);
    }
}

class SMSNotifierDecorator extends NotifierDecorator {
    public SMSNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String message) {
        super.send(message);
        String formattedMessage = formatMessage(message);
        System.out.println("Sending SMS: " + formattedMessage);
    }

    private String formatMessage(String message) {
        return "[SMS] " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + " - " + message;
    }
}

class SlackNotifierDecorator extends NotifierDecorator {
    public SlackNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String message) {
        super.send(message);
        String formattedMessage = formatMessage(message);
        System.out.println("Sending Slack message: " + formattedMessage);
    }

    private String formatMessage(String message) {
        return "[Slack] " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + " - " + message;
    }
}

public class DecoratorPatternExample {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier smsAndEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackAndSmsAndEmailNotifier = new SlackNotifierDecorator(smsAndEmailNotifier);

        System.out.println("Sending notification through Email:");
        emailNotifier.send("Hello via Email!");

        System.out.println("\nSending notification through Email and SMS:");
        smsAndEmailNotifier.send("Hello via Email and SMS!");

        System.out.println("\nSending notification through Email, SMS, and Slack:");
        slackAndSmsAndEmailNotifier.send("Hello via Email, SMS, and Slack!");
    }
}