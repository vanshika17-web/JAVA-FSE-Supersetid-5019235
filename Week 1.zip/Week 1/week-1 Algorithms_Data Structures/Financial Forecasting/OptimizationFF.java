public class OptimizationFF {
    private Map<Integer, Double> memo = new HashMap<>();

    // Recursive method to calculate future value with memoization
    public double calculateFutureValue(double presentValue, double growthRate, int years) {
        if (years == 0) {
            return presentValue;
        } else if (memo.containsKey(years)) {
            return memo.get(years);
        } else {
            double futureValue = calculateFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
            memo.put(years, futureValue);
            return futureValue;
        }
    }
}