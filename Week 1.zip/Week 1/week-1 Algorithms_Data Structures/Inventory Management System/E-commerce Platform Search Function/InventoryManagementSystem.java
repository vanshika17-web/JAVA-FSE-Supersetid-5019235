
public class InventoryManagementSystem {
    // Data structure to store products
    private HashMap<String, Product> products;

    public InventoryManagementSystem() {
        products = new HashMap<>();
    }

    // Methods to add, update, and delete products
    public void addProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    public void updateProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    public void deleteProduct(String productId) {
        products.remove(productId);
    }

    // Get product by ID
    public Product getProduct(String productId) {
        return products.get(productId);
    }
}